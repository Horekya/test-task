<?php

namespace App\Services;

use App\Services\Interfaces\NotificationServiceInterface;

class LogNotificationService implements NotificationServiceInterface
{

    function notify(string $event, array $data)
    {
        // TODO: Implement notify() method.
    }

    function makeNotificationEvent(string $event, array $data)
    {
        // TODO: Implement makeNotificationEvent() method.
    }
}
