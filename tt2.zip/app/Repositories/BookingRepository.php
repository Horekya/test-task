<?php
namespace App\Repositories;
use App\Models\Booking;
use App\Models\Product;
use App\Repositories\Interfaces\BookingRepositoryInterface;
use Illuminate\Database\Eloquent\Collection;

class BookingRepository implements BookingRepositoryInterface
{
    public function getByResourceId($resourceId): Collection
    {
        return Product::findOrFail($resourceId)->bookings;
    }

    public function save(Booking $booking)
    {
        // TODO: Implement save() method.
    }

    public function cancel($id)
    {
        // TODO: Implement cancel() method.
    }
}
