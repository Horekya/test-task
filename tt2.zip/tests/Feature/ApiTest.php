<?php

namespace Tests\Feature;

use App\Repositories\BookingRepository;
use App\Repositories\Interfaces\BookingRepositoryInterface;
use App\Repositories\Interfaces\ProductRepositoryInterface;
use App\Repositories\ProductRepository;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ApiTest extends TestCase
{
    public function setUp(): void
    {
        parent::setUp();
        $this->app->bindIf(BookingRepositoryInterface::class, BookingRepository::class);
        $this->app->bindIf(ProductRepositoryInterface::class, ProductRepository::class);
    }

    /**
     * A basic feature test example.
     */
    public function test_product_get_all_request(): void
    {
        $response = $this->get('/api/resources');

        $response->assertStatus(200);
    }

    public function test_product_put_request(): void
    {
        $response = $this->post('/api/resources',['name' => 'test_product', 'type' => 'test_type', 'description' => 'test_description']);

        $response->assertStatus(200);
    }
}
